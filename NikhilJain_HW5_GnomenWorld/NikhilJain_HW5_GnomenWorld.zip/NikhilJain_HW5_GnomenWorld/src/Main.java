import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/***
 * 
 * This class is the Main.java file. It is the launchpoint of the program, and it calls all the
 * necessary functions to kickstart the program.
 * 
 * @author Nikhil J
 *
 */



public class Main {
	
	// list with all the villages in it
	public static List<VillageNode> villageNodeList = new ArrayList<VillageNode>();

	public static void main(String[] args) {
		
		System.out.println("Launching program.");
		
		// Build the DisplayGraphGUI
		DisplayGraphGui displayGraphGui = new DisplayGraphGui();
		
		// transfer the initial village node data
		villageNodeList = displayGraphGui.villageNodeList;
		
		// test the popup
//		VillageNode node = new VillageNode(1, null, null);
//		VillageDetailsPopup p = new VillageDetailsPopup(node);
		
		
		
		
	} // end of main

} // end of class
